create table Positions (
id int primary key identity,
name nvarchar(30)
);

create table Staffs (
id int primary key identity,
position_id int foreign key references Positions(id) on delete cascade,
fcs nvarchar(30),
login nvarchar(50),
password nvarchar(20)
);

create table EntryTypes (
id int primary key identity,
name nvarchar(10)
);

create table LoginHistory (
id int primary key identity,
staff_id int foreign key references Staffs(id) on delete cascade,
last_entry date,
time_last_entry time,
entry_types_id int foreign key references EntryTypes(id) on delete cascade
);

create table Streets (
id int primary key identity,
name nvarchar(30)
);

create table Cities (
id int primary key identity,
name nvarchar(30)
);

create table Address (
id int primary key identity,
postal_code int,
city_id int foreign key references Cities(id) on delete cascade,
street_id int foreign key references Streets(id) on delete cascade,
house nvarchar(10),
flat int
);

create table Customers (
id int primary key,
fcs nvarchar(50),
series nvarchar(4),
number nvarchar(6),
date_birth date,
address_id int foreign key references Address(id) on delete cascade,
email nvarchar(50),
password nvarchar(30)
);

create table Services (
id int primary key identity,
name nvarchar(100),
kod nvarchar(20),
price float
);

create table OrderStatuses (
id int primary key identity,
name nvarchar(10)
);

create table Orders (
id int primary key identity,
date_create date,
time_create time,
customers_id int foreign key references Customers(id) on delete cascade,
order_statuses_id int foreign key references OrderStatuses(id) on delete cascade,
date_close date,
rental_time int
);

create table ServicesOrders (
id int primary key identity,
orders_id int foreign key references Orders(id) on delete cascade,
services_id int foreign key references Services(id) on delete cascade
);