﻿using PP.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PP
{
    /// <summary>
    /// Логика взаимодействия для AddOrder.xaml
    /// </summary>
    public partial class AddOrder : Window
    {
        Seller seller;
        Customer customer = new Customer();
        List<Service> services = new List<Service>();
        public AddOrder(Window window)
        {
            InitializeComponent();

            this.Owner = window;
            seller = (Seller)window;

            DbPark dbPark = new DbPark();
            ListViewCustomers.ItemsSource = dbPark.Customers.ToList();
            ListViewServices.ItemsSource  = dbPark.Services.ToList();
        }

        // Проверки и создание
        private void BorderSave_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (customer == null)
            {
                MessageBox.Show("Вы не указали клиента", "Ошибка");
                return;
            }

            if (services.Count == 0)
            {
                MessageBox.Show("Вы не указали услуги", "Ошибка");
                return;
            }

            if (TextBoxRentalTime.Text == "")
            {
                MessageBox.Show("Вы не ввели время проката", "Ошибка");
                return;
            }

            if (!int.TryParse(TextBoxRentalTime.Text, out int resRentalTime))
            {
                MessageBox.Show("Вы ввели не время проката", "Ошибка");
                return;
            }

            DbPark dbPark = new DbPark();
            Order order = new Order()
            {
                date_create = DateTime.Now,
                time_create = DateTime.Now.TimeOfDay,
                customers_id = customer.id,
                order_statuses_id = 3,
                rental_time = resRentalTime
            };

            dbPark.Orders.Add(order);
            dbPark.SaveChanges();

            foreach (var item in services)
            {
                ServicesOrder servicesOrder = new ServicesOrder()
                {
                    orders_id = order.id,
                    services_id = item.id
                };
                dbPark.ServicesOrders.Add(servicesOrder);
                dbPark.SaveChanges();
            }

            seller.GiveListView();
            CloseWin();
        }

        // Отмена
        private void BorderClose_MouseDown(object sender, MouseButtonEventArgs e)
        {
            CloseWin();
        }

        // Зактытие
        private void CloseWin()
        {
            seller.IsEnabled = true;
            Close();
            seller.Focus();
        }

        // Обработка закрытия
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            seller.IsEnabled = true;
            seller.Focus();
        }

        // Поиск
        private void TextBoxSerchCustomers_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            Searching.Search(ListViewCustomers, ListViewCustomers.ItemsSource, TextBoxSerchCustomers);
            ListViewCustomers.UpdateLayout();
            foreach (var item in ListViewCustomers.Items)
            {
                if (item is Customer customerItem)
                {
                    var container = ListViewCustomers.ItemContainerGenerator.ContainerFromItem(item) as ListViewItem;
                    if (container != null)
                    {
                        var radioButton = FindVisualChild<RadioButton>(container);
                        if (radioButton != null)
                        {
                            radioButton.IsChecked = (customerItem == customer);
                        }
                    }
                }
            }
        }

        // Получение выбранного клиента
        private Customer GetCustomer()
        {
            foreach (var item in ListViewCustomers.Items)
            {
                if (item is Customer customerItem)
                {
                    var container = ListViewCustomers.ItemContainerGenerator.ContainerFromItem(item) as ListViewItem;
                    if (container != null)
                    {
                        var radioButton = FindVisualChild<RadioButton>(container);
                        if (radioButton != null && radioButton.IsChecked == true)
                        {
                            return customerItem;
                        }
                    }
                }
            }
            return null;
        }

        // Находжение дочерних radiobox и checkbox
        private T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T result)
                    return result;

                var descendant = FindVisualChild<T>(child);
                if (descendant != null)
                    return descendant;
            }
            return null;
        }
        
        // Выбор клиента
        private void RadioButtonCustomer_Click(object sender, RoutedEventArgs e)
        {
            customer = GetCustomer();
        }

        // Поиск услуг
        private void TextBoxSerchServies_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            Searching.Search(ListViewServices, ListViewServices.ItemsSource, TextBoxSerchServices);

            ListViewServices.UpdateLayout();
            foreach (var item in ListViewServices.Items)
            {
                if (item is Service serviceItem)
                {
                    var container = ListViewServices.ItemContainerGenerator.ContainerFromItem(item) as ListViewItem;
                    if (container != null)
                    {
                        var checkBox = FindVisualChild<CheckBox>(container);
                        if (checkBox != null)
                        {
                            if (services.FirstOrDefault(p => p == serviceItem) != null)
                            {
                                checkBox.IsChecked = true;
                            }
                        }
                    }
                }
            }
        }

        // Получение списка услуг
        private void CheckBoxService_Click(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            if (checkBox.IsChecked == true)
            {
                services.Add(checkBox.DataContext as Service);
            }
            else
            {
                services.Remove(checkBox.DataContext as Service);
            }
        }
    }
}
