﻿using PP.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PP
{
    /// <summary>
    /// Логика взаимодействия для AddCustomer.xaml
    /// </summary>
    public partial class AddCustomer : Window
    {
        Seller seller;
        public AddCustomer(Window window)
        {
            InitializeComponent();

            this.Owner = window;
            seller = (Seller)window;

            DbPark dbPark = new DbPark();
            ComboBoxCity.ItemsSource = dbPark.Cities.ToList();
            ComboBoxStreet.ItemsSource = dbPark.Streets.ToList();
        }

        // Проверки и создание
        private void BorderSave_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DbPark dbPark = new DbPark();

            if (TextBoxKod.Text == "")
            {
                MessageBox.Show("Вы не ввели код", "Ошибка");
                return;
            }

            if (!int.TryParse(TextBoxKod.Text, out int resKod))
            {
                MessageBox.Show("Вы ввели не код", "Ошибка");
                return;
            }

            Customer customerKod = dbPark.Customers.FirstOrDefault(p => p.id == resKod);
            if (customerKod != null)
            {
                MessageBox.Show("Этот код занят", "Ошибка");
                return;
            }

            if (TextBoxLastName.Text == "")
            {
                MessageBox.Show("Вы не ввели фамилию", "Ошибка");
                return;
            }

            if (TextBoxFirstName.Text == "")
            {
                MessageBox.Show("Вы не ввели имя", "Ошибка");
                return;
            }

            if (TextBoxPatronumic.Text == "")
            {
                MessageBox.Show("Вы не ввели отчество", "Ошибка");
                return;
            }

            if (TextBoxSeries.Text == "")
            {
                MessageBox.Show("Вы не ввели серию паспорта", "Ошибка");
                return;
            }

            if (!int.TryParse(TextBoxSeries.Text, out int resSeries) || TextBoxSeries.Text.Length != 4)
            {
                MessageBox.Show("Вы ввели не серию паспорта", "Ошибка");
                return;
            }

            if (TextBoxNumber.Text == "")
            {
                MessageBox.Show("Вы не ввели номер паспорта", "Ошибка");
                return;
            }

            if (!int.TryParse(TextBoxNumber.Text, out int resNumber) || TextBoxNumber.Text.Length != 6)
            {
                MessageBox.Show("Вы ввели не номер паспорта", "Ошибка");
                return;
            }

            if (TextBoxDateBirth.Text == "")
            {
                MessageBox.Show("Вы не ввели дату рождения", "Ошибка");
                return;
            }

            if (!DateTime.TryParse(TextBoxDateBirth.Text, out DateTime resDateBirth))
            {
                MessageBox.Show("Вы ввели не дату", "Ошибка");
                return;
            }

            if (TextBoxEmail.Text == "")
            {
                MessageBox.Show("Вы не ввели электронную почту", "Ошибка");
                return;
            }

            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            if (!regex.IsMatch(TextBoxEmail.Text))
            {
                MessageBox.Show("Вы ввели не электронную почту", "Ошибка");
                return;
            }

            if (TextBoxPostalCode.Text == "")
            {
                MessageBox.Show("Вы не ввели индекс", "Ошибка");
                return;
            }

            if (!int.TryParse(TextBoxPostalCode.Text, out int resPostalCode) || TextBoxPostalCode.Text.Length != 6)
            {
                MessageBox.Show("Вы ввели не индекс", "Ошибка");
                return;
            }

            if (ComboBoxCity.SelectedIndex == -1)
            {
                MessageBox.Show("Вы не выбрали город", "Ошибка");
                return;
            }

            if (ComboBoxStreet.SelectedIndex == -1)
            {
                MessageBox.Show("Вы не выбрали улицу", "Ошибка");
                return;
            }

            if (TextBoxHouse.Text == "")
            {
                MessageBox.Show("Вы не ввели дом", "Ошибка");
                return;
            }

            if (TextBoxFlat.Text == "")
            {
                MessageBox.Show("Вы не ввели квартиру", "Ошибка");
                return;
            }

            if (!int.TryParse(TextBoxFlat.Text, out int resFlat))
            {
                MessageBox.Show("Вы ввели не квартиру", "Ошибка");
                return;
            }

            Address address = new Address()
            {
                postal_code = resPostalCode,
                city_id = ((City)ComboBoxCity.SelectedItem).id,
                street_id = ((Street)ComboBoxStreet.SelectedItem).id,
                house = TextBoxHouse.Text,
                flat = resFlat
            };
            dbPark.Addresses.Add(address);
            dbPark.SaveChanges();

            Customer customer = new Customer()
            {
                id = resKod,
                fcs = $"{TextBoxLastName.Text} " +
                $"{TextBoxFirstName.Text} {TextBoxPatronumic.Text}",
                email = TextBoxEmail.Text,
                date_birth = resDateBirth,
                series = resSeries.ToString(),
                number = resNumber.ToString(),
                address_id = address.id
            };

            dbPark.Customers.Add(customer);
            dbPark.SaveChanges();
            seller.GiveListView();
            CloseWin();
        }

        // Отмена
        private void BorderClose_MouseDown(object sender, MouseButtonEventArgs e)
        {
            CloseWin();
        }

        // Зактытие
        private void CloseWin()
        {
            seller.IsEnabled = true;
            Close();
            seller.Focus();
        }

        // Обработка события закрытия
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            seller.IsEnabled = true;
            seller.Focus();
        }
    }
}
