﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;

namespace PP
{
    public class Searching
    {
        public static void Search(ListView listView, object list, TextBox textBox)
        {
            var view = CollectionViewSource.GetDefaultView(list);

            view.Filter = obj => UniversalFilter(obj, textBox.Text);
            ICollectionView itemsView = view;

            listView.ItemsSource = itemsView;
        }

        private static bool UniversalFilter(dynamic item, string searchText)
        {
            if (string.IsNullOrEmpty(searchText))
                return true;

            searchText = searchText.ToLower();
            return SearchRecursive(item, searchText, new HashSet<object>());
        }

        private static bool SearchRecursive(object obj, string searchText, HashSet<object> visited)
        {
            if (obj == null || visited.Contains(obj))
                return false;

            visited.Add(obj);

            var properties = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (var property in properties)
            {
                try
                {
                    if (property.GetIndexParameters().Length > 0)
                        continue;

                    var value = property.GetValue(obj);

                    if (value == null)
                        continue;

                    if (IsSimpleType(value.GetType()))
                    {
                        if (value.ToString().ToLower().Contains(searchText))
                            return true;
                    }
                    else if (value is string stringValue)
                    {
                        if (stringValue.ToLower().Contains(searchText))
                            return true;
                    }
                    else if (value is System.Collections.IEnumerable enumerable && !(value is string))
                    {
                        continue;
                    }
                    else if (visited.Count < 10)
                    {
                        if (SearchRecursive(value, searchText, visited))
                            return true;
                    }
                }
                catch { }
            }

            return false;
        }

        private static bool IsSimpleType(Type type)
        {
            return type.IsPrimitive ||
                   type.IsEnum ||
                   type == typeof(string) ||
                   type == typeof(decimal) ||
                   type == typeof(DateTime) ||
                   type == typeof(TimeSpan) ||
                   type == typeof(Guid) ||
                   Nullable.GetUnderlyingType(type) != null;
        }
    }
}
