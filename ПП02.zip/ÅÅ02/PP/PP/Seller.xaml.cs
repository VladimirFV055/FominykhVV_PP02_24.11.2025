﻿using PP.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using static PP.Admin;

namespace PP
{
    /// <summary>
    /// Логика взаимодействия для Seller.xaml
    /// </summary>
    public partial class Seller : Window
    {
        private int id;
        public Seller(int id)
        {
            InitializeComponent();
            this.id = id;
            SetTimer();
            GiveName();
            GiveListView();
        }

        // Создание таймера
        DispatcherTimer timerTime = new DispatcherTimer();
        TimeSpan time = TimeSpan.Zero;
        private void SetTimer()
        {
            timerTime.Tick += TimerTime_Tick;
            timerTime.Interval = TimeSpan.FromSeconds(1);
            timerTime.Start();
        }

        private void GiveName()
        {
            DbPark dbPark = new DbPark();
            Staff staff = dbPark.Staffs.FirstOrDefault(p => p.id == id);
            TextBlockName.Text = staff.fcs;
        }

        // Вывод таймера
        private void TimerTime_Tick(object sender, EventArgs e)
        {
            time += TimeSpan.FromSeconds(1);
            this.Title = $"Продавец {time:hh\\:mm\\:ss}";
        }

        // Выход
        private void BorderClose_MouseDown(object sender, MouseButtonEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }

        // Вывод списков
        public void GiveListView()
        {
            DbPark dbPark = new DbPark();
            ListViewOrder.ItemsSource = dbPark.Orders.ToList()
                .Select(o => new OrderFormat
                {
                    id = o.id,
                    date_create = o.date_create,
                    date_close = o.date_close,
                    order_statuses_id = o.order_statuses_id,
                    customers_id = o.customers_id,
                    rental_time = o.rental_time,
                    time_create = o.time_create,
                    OrderStatus = o.OrderStatus,
                    Customer = o.Customer,
                    ServicesOrders = o.ServicesOrders
                }).ToList();

            ListViewCustomers.ItemsSource = dbPark.Customers
                .Select(o => new CustomerFormat
                {
                    id = o.id,
                    series = o.series,
                    email = o.email,
                    address_id = o.address_id,
                    date_birth = o.date_birth,
                    fcs = o.fcs,
                    number = o.number,
                    password = o.password,
                    Orders = o.Orders,
                    Address = o.Address
                }).ToList();
        }

        // Вспомогательный класс для вывода клиентов
        public class CustomerFormat : Customer
        {
            public string AddressString
            {
                get
                {
                    return $"{Address.postal_code} г. {Address.City.name}" +
                        $", ул. {Address.Street.name}, д. {Address.house}, кв. {Address.flat}";
                }
            }
        }

        private void ImageAddCustomer_MouseDown(object sender, MouseButtonEventArgs e)
        {
            AddCustomer addCustomer = new AddCustomer(this);
            addCustomer.Show();
            this.IsEnabled = false;
        }

        private void TextBox_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            Searching.Search(ListViewCustomers, ListViewCustomers.ItemsSource, TextBoxSearchCustomers);
        }

        private void ImageAddOrder_MouseDown(object sender, MouseButtonEventArgs e)
        {
            AddOrder addOrder = new AddOrder(this);
            addOrder.Show();
            this.IsEnabled = false;
        }

        private void TextBoxSearchOrders_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            Searching.Search(ListViewOrder, ListViewOrder.ItemsSource, TextBoxSearchOrders);
        }
    }
}