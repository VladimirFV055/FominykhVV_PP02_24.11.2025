﻿using PP.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PP
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int staff_id;
        public MainWindow()
        {
            InitializeComponent();

            timer.Tick += Timer_Tick;
            timer.Interval = TimeSpan.FromSeconds(1);
        }

        private void CapchaTimer_Tick(object sender, EventArgs e)
        {
            capchaTimer.Stop();
            GenerateCaptcha();


            //      Убрать
            //TextBoxCapcha.Text = currentCaptchaText;
        }

        int time = 0;
        private void Timer_Tick(object sender, EventArgs e)
        {
            time++;
            if (time == 10)
            {
                timer.Stop();
                time = 0;
                this.IsEnabled = true;
            }
        }

        int popitki = 0;
        DispatcherTimer timer = new DispatcherTimer();
        DispatcherTimer capchaTimer = new DispatcherTimer();
        private void BorderAvt_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DbPark dbPark = new DbPark();


            if (TextBoxLogin.Text.Trim() == "")
            {
                MessageBox.Show("Вы не ввели логин", "Ошибка");
                return;
            }

            if (!flagEye)
            {
                if (PasswordBoxPass.Password.Trim() == "")
                {
                    MessageBox.Show("Вы не ввели пароль", "Ошибка");
                    return;
                }
            }
            else
            {
                if (TextBoxPass.Text.Trim() == "")
                {
                    MessageBox.Show("Вы не ввели пароль", "Ошибка");
                    return;
                }
            }

            Staff staff = dbPark.Staffs.Where(p => p.login == TextBoxLogin.Text).FirstOrDefault();
            staff_id = staff.id;
            if (staff == null)
            {
                MessageBox.Show("Пользователя с таким логином не существует", "Ошибка");
                return;
            }


            if (!flagEye)
            {
                if (staff.password != PasswordBoxPass.Password)
                {
                    MessageBox.Show("Пароль не верный", "Ошибка");
                    popitki++;
                    ProverkaPopitok();
                    return;
                }
            }
            else
            {
                if (staff.password != TextBoxPass.Text.Trim())
                {
                    MessageBox.Show("Пароль не верный", "Ошибка");
                    popitki++;
                    ProverkaPopitok();
                    return;
                }
            }

            if (TextBoxCapcha.Text != currentCaptchaText && popitki >= 3)
            {
                MessageBox.Show("Капча введена не верно", "Ошибка");
                popitki++;
                ProverkaPopitok();
                GenerateCaptcha();
                return;
            }

            CreateLoginHistory(2);

            switch (staff.position_id)
            {
                case 1:
                    Admin admin = new Admin(staff.id);
                    admin.Show();
                    break;

                case 2:
                case 3:
                    Seller seller = new Seller(staff.id);
                    seller.Show();
                    break;
            }
            Close();
        }

        private void ProverkaPopitok()
        {
            CreateLoginHistory();
            if (popitki == 3)
            {
                this.IsEnabled = false;
                timer.Start();
                StackPanelCapcha.Visibility = Visibility.Visible;
                capchaTimer.Tick += CapchaTimer_Tick;
                capchaTimer.Interval = TimeSpan.FromSeconds(0.1);
                capchaTimer.Start();
            }
        }

        private void CreateLoginHistory(int type = 1)
        {
            DbPark dbPark = new DbPark();
            LoginHistory loginHistory = new LoginHistory()
            {
                entry_types_id = type,
                staff_id = this.staff_id,
                last_entry = DateTime.Now,
                time_last_entry = DateTime.Now.TimeOfDay
            };
            dbPark.LoginHistories.Add(loginHistory);
            dbPark.SaveChanges();
        }

        private bool flagEye = false;
        private void BorderEye_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (flagEye)
            {
                flagEye = false;
                PasswordBoxPass.Visibility = Visibility.Visible;
                TextBoxPass.Visibility = Visibility.Collapsed;
                PasswordBoxPass.Password = TextBoxPass.Text;
                ImageEye.Source = new BitmapImage(new Uri($"{Directory.GetCurrentDirectory()}\\Image\\eyeClose.png", UriKind.Absolute));
            }
            else
            {
                flagEye = true;
                TextBoxPass.Visibility = Visibility.Visible;
                PasswordBoxPass.Visibility = Visibility.Collapsed;
                TextBoxPass.Text = PasswordBoxPass.Password;
                ImageEye.Source = new BitmapImage(new Uri($"{Directory.GetCurrentDirectory()}\\Image\\eyeOpen.png", UriKind.Absolute));
            }
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            GenerateCaptcha();
        }

        private string currentCaptchaText;
        private Random random = new Random();
        private void GenerateCaptcha()
        {
            captchaCanvas.Children.Clear();
            DrawNoise();
            currentCaptchaText = GenerateRandomText(4);
            DrawText(currentCaptchaText);
        }

        private string GenerateRandomText(int length)
        {
            const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ1234567890";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        // Добавление символов в отдельных textblock
        private void DrawText(string text)
        {
            double x = 10;

            for (int i = 0; i < text.Length; i++)
            {
                var textBlock = new TextBlock
                {
                    Text = text[i].ToString(),
                    FontSize = random.Next(15, 23),
                    FontWeight = FontWeights.Bold,
                    Foreground = GetRandomColor(),
                    RenderTransform = GetRandomTransform()
                };

                Canvas.SetLeft(textBlock, x);
                Canvas.SetTop(textBlock, random.Next(5, 40));

                captchaCanvas.Children.Add(textBlock);

                x += 25 + random.Next(-5, 5);
            }
        }

        // Графический шум
        private void DrawNoise()
        {
            // Добавляем случайные линии
            for (int i = 0; i < 5; i++)
            {
                var line = new Line
                {
                    X1 = random.Next(0, (int)captchaCanvas.ActualWidth),
                    Y1 = random.Next(0, (int)captchaCanvas.ActualHeight),
                    X2 = random.Next(0, (int)captchaCanvas.ActualWidth),
                    Y2 = random.Next(0, (int)captchaCanvas.ActualHeight),
                    Stroke = GetRandomColor(),
                    StrokeThickness = random.Next(1, 3)
                };
                captchaCanvas.Children.Add(line);
            }

            // Добавляем случайные точки
            for (int i = 0; i < 30; i++)
            {
                var ellipse = new Ellipse
                {
                    Width = random.Next(1, 3),
                    Height = random.Next(1, 3),
                    Fill = GetRandomColor()
                };

                Canvas.SetLeft(ellipse, random.Next(0, (int)captchaCanvas.ActualWidth));
                Canvas.SetTop(ellipse, random.Next(0, (int)captchaCanvas.ActualHeight));

                captchaCanvas.Children.Add(ellipse);
            }
        }

        // Выдача цвета
        private System.Windows.Media.Brush GetRandomColor()
        {
            var colors = new[]
            {
                Colors.Black,
                Colors.DarkBlue,
                Colors.DarkGreen,
                Colors.DarkRed,
                Colors.Purple,
                Colors.Brown
            };

            return new SolidColorBrush(colors[random.Next(colors.Length)]);
        }

        // Вращение textblock
        private Transform GetRandomTransform()
        {
            var transformGroup = new TransformGroup();
            transformGroup.Children.Add(new SkewTransform(
                random.Next(-10, 10),
                random.Next(-10, 10)));

            transformGroup.Children.Add(new RotateTransform(
                random.Next(-15, 15)));

            return transformGroup;
        }
    }
}
