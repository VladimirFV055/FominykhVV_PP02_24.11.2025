﻿using PP.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PP
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        private int id;
        public Admin(int id)
        {
            InitializeComponent();
            this.id = id;
            SetTimer();
            GiveListView();
            GiveName();
        }

        // Создание таймера
        DispatcherTimer timerTime = new DispatcherTimer();
        TimeSpan time = TimeSpan.Zero;
        private void SetTimer()
        {
            timerTime.Tick += TimerTime_Tick;
            timerTime.Interval = TimeSpan.FromSeconds(1);
            timerTime.Start();
        }

        // Вывод таймера
        private void TimerTime_Tick(object sender, EventArgs e)
        {
            time += TimeSpan.FromSeconds(1);
            this.Title = $"Администратор {time:hh\\:mm\\:ss}";
        }

        private void GiveName()
        {
            DbPark dbPark = new DbPark();
            Staff staff = dbPark.Staffs.FirstOrDefault(p => p.id == id);
            TextBlockName.Text = staff.fcs;
        }

        // Вывод списков
        private void GiveListView()
        {
            DbPark dbPark = new DbPark();
            ListViewLoginHistory.ItemsSource = dbPark.LoginHistories.ToList();
            ListViewOrder.ItemsSource = dbPark.Orders.ToList()
                .Select(o => new OrderFormat
                {
                    id = o.id,
                    date_create = o.date_create,
                    date_close = o.date_close,
                    order_statuses_id = o.order_statuses_id,
                    customers_id = o.customers_id,
                    rental_time = o.rental_time,
                    time_create = o.time_create,
                    OrderStatus = o.OrderStatus,
                    Customer = o.Customer,
                    ServicesOrders = o.ServicesOrders
                }).ToList();
            ComboBoxLoginStaffHistory.ItemsSource = dbPark.Staffs.ToList();
        }

        // Вспомогательный класс для вывода заказов
        public class OrderFormat : Order
        {
            private DbPark park = new DbPark();

            public string Summ
            {
                get
                {
                    return park.ServicesOrders
                              .Where(p => p.orders_id == id)
                              .Sum(s => s.Service.price).ToString();
                }
            }

            public string Kod
            {
                get
                {
                    return $"{customers_id}/{date_create:dd.MM.yyyy}";
                }
            }
        }

        // Сброс фильтра
        private void BorderDrop_MouseDown(object sender, MouseButtonEventArgs e)
        {
            GiveListView();
        }

        // Применение фильтров
        private void ComboBoxLoginStaff_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Staff staff = ComboBoxLoginStaffHistory.SelectedItem as Staff;
            if (staff != null)
            {
                DbPark dbPark = new DbPark();
                ListViewLoginHistory.ItemsSource = dbPark.LoginHistories.Where(p => p.staff_id == staff.id).ToList();
            }
        }

        // Выход
        private void BorderClose_MouseDown(object sender, MouseButtonEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
